<?
$menu["menu405"] = array (
	array("", "스팸관리", "$g4[admin_path]/antispam/adm_config.php"),
    array("405100", "설정", "$g4[admin_path]/antispam/adm_config.php"),
	array("405400", "스팸차단로그", "$g4[admin_path]/antispam/adm_log.php"),
    array("405300", "전체게시글목록", "$g4[admin_path]/antispam/adm_document_list.php"),
	array("405200", "스팸게시글관리", "$g4[admin_path]/antispam/adm_store.php"),
	array("405500", "계정/IP차단관리", "$g4[admin_path]/antispam/adm_black_list.php"),
);
?>
