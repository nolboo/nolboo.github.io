<?
$g4_path  = "../../../";
include_once("$g4_path/common.php");
$base = $g4[admin_path];
?>