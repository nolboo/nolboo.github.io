<?php
header("Location: ./install/install.php"); 
?>